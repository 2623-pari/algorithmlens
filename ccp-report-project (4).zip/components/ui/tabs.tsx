"use client"

import * as React from "react"
import type * as TabsPrimitive from "@radix-ui/react-tabs"

const TabsContext = React.createContext<{ value: string; setValue: (v: string) => void } | null>(null)

function Tabs({
  defaultValue,
  className,
  children,
}: React.ComponentProps<typeof TabsPrimitive.Root> & { defaultValue: string; children: React.ReactNode }) {
  const [value, setValue] = React.useState(defaultValue)
  const ctx = React.useMemo(() => ({ value, setValue }), [value])
  return (
    <div className={className}>
      <TabsContext.Provider value={ctx}>{children}</TabsContext.Provider>
    </div>
  )
}

function TabsList({
  className,
  children,
}: React.ComponentProps<typeof TabsPrimitive.List> & { children: React.ReactNode }) {
  return <div className={className}>{children}</div>
}

function TabsTrigger({
  value,
  children,
}: React.ComponentProps<typeof TabsPrimitive.Trigger> & { value: string; children: React.ReactNode }) {
  const ctx = React.useContext(TabsContext)!
  const active = ctx.value === value
  return (
    <button
      onClick={() => ctx.setValue(value)}
      className={`rounded-md border px-3 py-2 text-sm ${active ? "bg-blue-600 text-white" : "bg-background"}`}
    >
      {children}
    </button>
  )
}

function TabsContent({
  value,
  children,
  className,
}: React.ComponentProps<typeof TabsPrimitive.Content> & {
  value: string
  children: React.ReactNode
  className: string
}) {
  const ctx = React.useContext(TabsContext)!
  if (ctx.value !== value) return null
  return <div className={className}>{children}</div>
}

export { Tabs, TabsList, TabsTrigger, TabsContent }
