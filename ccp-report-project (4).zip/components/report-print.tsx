"use client"

export type Student = { name: string; regNo: string }

type ReportData = {
  title: string
  projectTitle: string
  students: Student[]
  month: string
  year: string
  abstractText: string
  ackText: string
  chapters: { title: string; content: string }[]
}

export default function ReportPrint({ data }: { data: ReportData }) {
  const { title, projectTitle, students, month, year, abstractText, ackText, chapters } = data

  const submittedByLine = students.map((s) => `${s.name} ${s.regNo}`).join(", ")

  return (
    <div className="relative">
      {/* Print styles scoped to report */}
      <style>{`
        @media print {
          /* Hide everything except the report container */
          body * { visibility: hidden; }
          #ccp-report-root, #ccp-report-root * { visibility: visible; }
          #ccp-report-root {
            position: absolute;
            inset: 0;
            margin: 0 !important;
          }
        }

        /* Page setup */
        @page {
          size: A4;
          margin: 25mm 20mm 25mm 20mm;
        }

        .tnr { font-family: "Times New Roman", Times, serif; }
        .line15 { line-height: 1.5; }
        .para { margin: 0; }
        .para + .para { margin-top: 1.2rem; } /* ~2 lines visual gap on 1.5 lh */
        .center { text-align: center; }
        .title18 { font-size: 18pt; font-weight: 700; }
        .mb16 { margin-bottom: 16px; }
        .mt16 { margin-top: 16px; }
        .mt24 { margin-top: 24px; }
        .mt32 { margin-top: 32px; }
        .mb24 { margin-bottom: 24px; }
        .page-break { page-break-before: always; }
        .small { font-size: 11.5pt; }
        .normal { font-size: 12pt; }
        .bold { font-weight: 700; }
        .underline { text-decoration: underline; }
        .section-title { font-size: 14pt; font-weight: 700; margin: 16px 0 8px 0; }
        .hr { height: 1px; background: #e5e7eb; border: 0; margin: 12px 0; }
      `}</style>

      <div id="ccp-report-root" className="bg-white p-8 tnr line15 normal text-black">
        {/* Title Page */}
        <section className="center">
          <p className="title18">{projectTitle.toUpperCase()}</p>
          <p className="mt24 bold">{title}</p>
          <p className="mt24">Submitted by</p>
          <p className="bold">{submittedByLine}</p>

          <p className="mt24 bold">in partial fulfillment for the award of the degree</p>
          <p className="bold">of</p>
          <p className="bold">BACHELOR OF ENGINEERING</p>
          <p className="bold">in</p>
          <p className="bold">Computer Science &amp; Engineering</p>
          <p className="bold">(Artificial Intelligence and Machine Learning)</p>

          <p className="mt24">CHENNAI INSTITUTE OF TECHNOLOGY (AUTONOMOUS)</p>
          <p>(Affiliated to Anna University, Chennai)</p>
          <p>CHENNAI-600 069</p>
          <p>ANNA UNIVERSITY: CHENNAI-600 025</p>
          <p className="mt24">
            {month.toUpperCase()} - {year}
          </p>
        </section>

        <div className="page-break" />

        {/* Vision/Mission Pages - exact content from prompt */}
        <section>
          <p className="bold">Vision of the Institute:</p>
          <p className="para">
            To be an eminent centre for Academia, Industry and Research by imparting knowledge, relevant practices and
            inculcating human values to address global challenges through novelty and sustainability.
          </p>
          <p className="bold mt24">Mission of the Institute:</p>
          <p className="para">
            IM1: To create next generation leaders by effective teaching learning methodologies and in still scientific
            spark in them to meet the global challenges.
          </p>
          <p className="para">
            IM2: To transform lives through deployment of emerging technology, novelty and Sustainability.
          </p>
          <p className="para">IM3: To inculcate human values and ethical principles to cater to the societal needs.</p>
          <p className="para">
            IM4: To contribute towards the research ecosystem by providing a suitable, effective platform for
            interaction between industry, academia and R &amp; D establishments.
          </p>
          <p className="para">IM5: To nurture incubation centers enabling structured entrepreneurship and start-ups.</p>
          <hr className="hr" />
          <p className="bold">Vision of the Department:</p>
          <p className="para">
            Developing talented professionals in the fields of AI and ML that contribute to the benefit of business
            enterprise and societies around the world.
          </p>
          <p className="bold mt24">Mission of the Department:</p>
          <p className="para">
            DM1: To broaden kingdom of the art instructional and infrastructural facilities with current equipment and
            different gaining knowledge of assets to provide self-sustainable specialists.
          </p>
          <p className="para">
            DM2: To collaborate with enterprise and research Laboratories thru tasks-primarily based mastering,
            internships permitting the students to discover, apply diverse guidelines of learning.
          </p>
          <p className="para">
            DM3: To establish value creating networks and linkages with company, industries, academic institutes and
            universities of countrywide and global significance.
          </p>
          <p className="para">
            DM4: To equip students with interdisciplinary talent units to build intelligent structures which in flip
            affords dynamic and promising careers inside the worldwide marketplace.
          </p>
          <p className="mt24">
            CHENNAI INSTITUTE OF TECHNOLOGY
            <br />
            An Autonomous Institute
            <br />
            CHENNAI-69
          </p>
        </section>

        <div className="page-break" />

        {/* Bonafide Certificate */}
        <section>
          <p className="bold center">ANNA UNIVERSITY: CHENNAI-600 025</p>
          <p className="bold center mt16 underline">BONAFIDE CERTIFICATE</p>
          <p className="para mt24">
            Certified that this Core Course project report “{projectTitle}” Submitted by{" "}
            {students.map((s, i) => `${s.name} (Reg no: ${s.regNo})`).join(" and ")} is a work done by him/her and
            submitted during 2025-2026 academic year, in partial fulfillment of the requirements for the award of the
            degree of BACHELOR OF ENGINEERING in DEPARTMENT OF CSE (ARTIFICIAL INTELLIGENCE AND MACHINE LEARNING), at
            Chennai Institute of Technology.
          </p>

          <div className="grid grid-cols-2 gap-6 mt32">
            <div>
              <p className="bold">SIGNATURE</p>
              <p className="para mt16">Dr.R.Gowri, M.E., Ph.D.,</p>
              <p className="para">HEAD OF THE DEPARTMENT</p>
              <p className="para">Professor</p>
              <p className="para">
                Department of Computer Science &amp; Engineering, (Artificial Intelligence and Machine Learning)
              </p>
              <p className="para">Chennai Institute of Technology, Kundrathur, Chennai-600069.</p>
            </div>
            <div>
              <p className="bold">SIGNATURE</p>
              <p className="para mt16">Dr.P.Karthikeyan, M.E., Ph.D.,</p>
              <p className="para">Project Coordinator</p>
              <p className="para">Associate Professor</p>
              <p className="para">
                Department of Computer Science &amp; Engineering, (Artificial Intelligence and Machine Learning)
              </p>
              <p className="para">Chennai Institute of Technology, Kundrathur, Chennai-600069.</p>
            </div>
          </div>

          <p className="mt24">
            Certified that the above students have attend of viva voice during the exam held on
            .........................
          </p>

          <div className="grid grid-cols-2 gap-6 mt32">
            <p className="bold center">INTERNAL EXAMINER</p>
            <p className="bold center">EXTERNAL EXAMINER</p>
          </div>
        </section>

        <div className="page-break" />

        {/* Acknowledgement */}
        <section>
          <p className="bold center underline">ACKNOWLEDGEMENT</p>
          <p className="para mt16">
            We express our gratitude to our Chairman Shri.P. SRIRAM and all trust members of Chennai institute of
            technology for providing the facility and opportunity to do this project as a part of our undergraduate
            course.
          </p>
          <p className="para">
            We are grateful to our Principal Dr.A.RAMESH M.E., Ph.D., for providing us the facility and encouragement
            during the course of our work.
          </p>
          <p className="para">
            We sincerely thank our Head of the Department, Dr.R.Gowri, M.E., Ph.D., Department of Computer Science and
            Engineering, (Artificial Intelligence and Machine Learning) for having provided us valuable guidance,
            resources and timely suggestions throughout our work.
          </p>
          <p className="para">
            We sincerely thank our Core Course Project Guide, Dr.P.Karthikeyan M.E., Ph.D., Associate Professor,
            Department of Computer Science and Engineering, (Artificial Intelligence and Machine Learning) Engineering
            for having provided us valuable guidance, resources and timely suggestions throughout our work.
          </p>
          <p className="para">
            We would like to extend our thanks to our Faculty coordinators of the Department of Computer Science and
            Engineering, (Artificial Intelligence and Machine Learning), for their valuable suggestions throughout this
            project.
          </p>
          <p className="para">
            We wish to extend our sincere thanks to all Faculty members of the Department of Computer Science and
            Engineering, (Artificial Intelligence and Machine Learning) for their valuable suggestions and their kind
            cooperation for the successful completion of our project.
          </p>
          <p className="para">
            We wish to acknowledge the help received from the Lab Instructors of the Department of Computer Science and
            Engineering, (Artificial Intelligence and Machine Learning) and others for providing valuable suggestions
            and for the successful completion of the project.
          </p>
          <div className="mt24">
            {students.map((s) => (
              <p key={s.regNo} className="para">
                NAME: {s.name} &nbsp; REG.NO: {s.regNo}
              </p>
            ))}
          </div>
        </section>

        <div className="page-break" />

        {/* Abstract */}
        <section>
          <p className="bold center underline">ABSTRACT</p>
          <p className="para mt16">{abstractText}</p>
        </section>

        <div className="page-break" />

        {/* Table of Contents (static anchors) */}
        <section>
          <p className="bold center underline">TABLE OF CONTENTS</p>
          <p className="para mt16">
            List of Figures ................................................................. i
          </p>
          <p className="para">List of Tables ................................................................. ii</p>
          <p className="para">List of Abbreviations ..................................................... iii</p>
          <p className="para">Chapter 1: Introduction .................................................. 1</p>
          <p className="para">Chapter 2: Literature Review ........................................... 5</p>
          <p className="para">Chapter 3: Methodology .................................................. 10</p>
          <p className="para">Chapter 4: Results/Findings ............................................ 20</p>
          <p className="para">Chapter 5: Discussion ..................................................... 30</p>
          <p className="para">Chapter 6: Conclusion ..................................................... 40</p>
          <p className="para">References .................................................................... 44</p>
          <p className="para">Appendices .................................................................... 45</p>
        </section>

        <div className="page-break" />

        {/* Chapters 1-6 */}
        {chapters.map((ch, idx) => (
          <section key={idx} className={idx > 0 ? "page-break" : ""}>
            <p className="section-title">{ch.title}</p>
            <p className="para">{ch.content}</p>
          </section>
        ))}

        <div className="page-break" />

        {/* References */}
        <section>
          <p className="section-title">References</p>
          <p className="para">
            [1] Hart, P. E., Nilsson, N. J., Raphael, B. A Formal Basis for the Heuristic Determination of Minimum Cost
            Paths. IEEE TSSC, 1968.
          </p>
          <p className="para">
            [2] Dijkstra, E. W. A Note on Two Problems in Connexion with Graphs. Numerische Mathematik, 1959.
          </p>
          <p className="para">[3] Russell, S., Norvig, P. Artificial Intelligence: A Modern Approach, Pearson.</p>
          <p className="para">[4] Cormen, T. H., et al. Introduction to Algorithms, MIT Press.</p>
        </section>

        <div className="page-break" />

        {/* Appendices */}
        <section>
          <p className="section-title">Appendices</p>
          <p className="bold">Coding (Pseudo Code)</p>
          <p className="para">
            Dijkstra: Initialize distances INF, dist[start]=0; while unvisited: pick u with min dist; relax neighbors;
            stop at goal.
          </p>
          <p className="para">
            A*: g[n]=cost-so-far; f[n]=g[n]+h[n]; expand node with lowest f; update cameFrom; stop at goal and
            reconstruct path.
          </p>
          <p className="mt16 small">
            Note: Line spacing 1.5; approximate inter-paragraph spacing set to two lines as per template.
          </p>
        </section>
      </div>
    </div>
  )
}
