"use client"

type Props = {
  title: string
  student1Name: string
  student1Reg: string
  student2Name?: string
  student2Reg?: string
  yearSpan: string
  monthYear: string
  dept: string
  abstractText: string
  keywords: string
  ackText: string
}

export default function ReportPreview(props: Props) {
  const {
    title,
    student1Name,
    student1Reg,
    student2Name,
    student2Reg,
    yearSpan,
    monthYear,
    dept,
    abstractText,
    keywords,
    ackText,
  } = props

  const deptLines = dept.split("\n")

  return (
    <>
      <style jsx global>{`
        /* Print: only .print-area will render */
        @media print {
          body * {
            visibility: hidden !important;
          }
          .print-area,
          .print-area * {
            visibility: visible !important;
          }
          .print-area {
            position: absolute;
            inset: 0;
            margin: 0;
            padding: 0;
          }
          /* set A4 with 25mm top/bottom and 20mm sides (per template-friendly margins) */
          @page {
            size: A4;
            margin: 25mm 20mm 25mm 20mm;
          }
          .page-break {
            page-break-after: always;
          }
        }

        /* enforce "In-between Paragraph: 2" with 1.5 line spacing (36pt gap between consecutive paragraphs) */
        .report-content p {
          margin: 0;
        }
        .report-content p + p {
          margin-top: 36pt;
        }

        .report-content h3 {
          margin: 6pt 0 8pt;
        }
        .report-content h4 {
          margin: 6pt 0 6pt;
        }
        .report-content ul,
        .report-content ol {
          margin: 6pt 0 6pt 16pt;
        }
        .report-content table th,
        .report-content table td {
          vertical-align: top;
        }
      `}</style>

      <div className="print-area">
        <div className="report-content" style={{ fontFamily: '"Times New Roman", Times, serif', lineHeight: 1.5 }}>
          {/* Title Page */}
          <section className="page-break">
            <div className="mt-10 text-center">
              <h1 style={{ fontSize: "18pt", fontWeight: 700, textTransform: "uppercase" }}>{title}</h1>
              <h2 style={{ fontSize: "16pt", marginTop: "10pt" }}>A CORE COURSE PROJECT REPORT</h2>
              <p style={{ fontSize: "12pt", marginTop: "18pt" }}>Submitted by</p>
              <p style={{ fontSize: "12pt", fontWeight: 700 }}>
                {student1Name} {student1Reg || ""}
              </p>
              {student2Name ? (
                <p style={{ fontSize: "12pt", fontWeight: 700 }}>
                  {student2Name} {student2Reg || ""}
                </p>
              ) : null}
              <p style={{ fontSize: "12pt", marginTop: "10pt" }}>
                in partial fulfillment for the award of the degree of
              </p>
              <p style={{ fontSize: "12pt", fontWeight: 700, marginTop: "2pt" }}>BACHELOR OF ENGINEERING</p>
              <p style={{ fontSize: "12pt", marginTop: "6pt" }}>in</p>
              <p style={{ fontSize: "12pt", fontWeight: 700, marginTop: "2pt" }}>
                {deptLines.map((l, i) => (
                  <span key={i}>
                    {l}
                    {i < deptLines.length - 1 ? <br /> : null}
                  </span>
                ))}
              </p>
              <div style={{ marginTop: "24pt" }}>
                <p style={{ fontSize: "12pt", fontWeight: 700 }}>CHENNAI INSTITUTE OF TECHNOLOGY (AUTONOMOUS)</p>
                <p style={{ fontSize: "12pt" }}>(Affiliated to Anna University, Chennai)</p>
                <p style={{ fontSize: "12pt" }}>CHENNAI-600 069</p>
                <p style={{ fontSize: "12pt" }}>ANNA UNIVERSITY: CHENNAI-600 025</p>
                <p style={{ fontSize: "12pt", marginTop: "10pt" }}>{monthYear}</p>
              </div>
            </div>
          </section>

          {/* Declaration */}
          <section className="page-break" style={{ paddingTop: "12pt" }}>
            <h3 style={{ fontSize: "18pt", fontWeight: 700 }}>DECLARATION</h3>
            <p style={{ fontSize: "12pt", marginTop: "10pt" }}>
              I hereby declare that the project work entitled “{title}” submitted by me,{" "}
              <strong>
                {student1Name} ({student1Reg})
              </strong>
              {student2Name ? (
                <>
                  , and <strong>{student2Name}</strong>
                  {student2Reg ? ` (${student2Reg})` : ""}
                </>
              ) : null}{" "}
              during the academic year {yearSpan} is an authentic record of my work carried out under the guidance of
              the faculty of the Department of Computer Science & Engineering (Artificial Intelligence and Machine
              Learning), Chennai Institute of Technology. This work has not been submitted elsewhere for the award of
              any degree or diploma.
            </p>
            <div style={{ marginTop: "24pt", display: "flex", justifyContent: "space-between" }}>
              <div>
                <p>Place: Chennai</p>
                <p>Date: __ / __ / ____</p>
              </div>
              <div style={{ textAlign: "right" }}>
                <p>Signature of the Candidate</p>
                <p>
                  <strong>{student1Name}</strong> {student1Reg ? `(${student1Reg})` : ""}
                </p>
                {student2Name ? (
                  <p>
                    <strong>{student2Name}</strong> {student2Reg ? `(${student2Reg})` : ""}
                  </p>
                ) : null}
              </div>
            </div>
          </section>

          {/* Vision & Mission */}
          <section className="page-break" style={{ paddingTop: "12pt" }}>
            <h3 style={{ fontSize: "14pt", fontWeight: 700 }}>Vision of the Institute:</h3>
            <p>
              To be an eminent centre for Academia, Industry and Research by imparting knowledge, relevant practices and
              inculcating human values to address global challenges through novelty and sustainability.
            </p>
            <h4 style={{ fontSize: "13pt", fontWeight: 700, marginTop: "8pt" }}>Mission of the Institute:</h4>
            <ul style={{ marginLeft: "16pt" }}>
              <li>
                IM1: To create next generation leaders by effective teaching learning methodologies and instill
                scientific spark in them to meet the global challenges.
              </li>
              <li>IM2: To transform lives through deployment of emerging technology, novelty and Sustainability.</li>
              <li>IM3: To inculcate human values and ethical principles to cater to the societal needs.</li>
              <li>
                IM4: To contribute towards the research ecosystem by providing a suitable, effective platform for
                interaction between industry, academia and R & D establishments.
              </li>
              <li>IM5: To nurture incubation centers enabling structured entrepreneurship and start-ups.</li>
            </ul>

            <div style={{ marginTop: "14pt" }}>
              <h3 style={{ fontSize: "14pt", fontWeight: 700 }}>Vision of the Department:</h3>
              <p>
                Developing talented professionals in the fields of AI and ML that contribute to the benefit of business
                enterprise and societies around the world.
              </p>
              <h4 style={{ fontSize: "13pt", fontWeight: 700, marginTop: "8pt" }}>Mission of the Department:</h4>
              <ul style={{ marginLeft: "16pt" }}>
                <li>
                  DM1: To broaden state-of-the-art instructional and infrastructural facilities to provide
                  self-sustainable specialists.
                </li>
                <li>
                  DM2: To collaborate with industry and research laboratories through project-based learning and
                  internships.
                </li>
                <li>
                  DM3: To establish value-creating networks with companies, industries, and universities of national and
                  global significance.
                </li>
                <li>
                  DM4: To equip students with interdisciplinary skill sets to build intelligent systems that provide
                  dynamic and promising careers in the global marketplace.
                </li>
              </ul>
              <p style={{ marginTop: "10pt" }}>CHENNAI INSTITUTE OF TECHNOLOGY, An Autonomous Institute, CHENNAI-69</p>
            </div>
          </section>

          {/* Bonafide Certificate */}
          <section className="page-break" style={{ paddingTop: "12pt" }}>
            <h3 style={{ fontSize: "14pt", fontWeight: 700 }}>ANNA UNIVERSITY: CHENNAI-600 025</h3>
            <h4 style={{ fontSize: "13pt", fontWeight: 700, marginTop: "6pt" }}>BONAFIDE CERTIFICATE</h4>
            <p style={{ marginTop: "8pt" }}>
              Certified that this Core Course project report “{title}” submitted by{" "}
              <strong>
                {student1Name} ({student1Reg})
                {student2Name ? ` and ${student2Name}${student2Reg ? ` (${student2Reg})` : ""}` : ""}
              </strong>{" "}
              is a work done by him/her and submitted during {yearSpan} academic year, in partial fulfillment of the
              requirements for the award of the degree of BACHELOR OF ENGINEERING in DEPARTMENT OF CSE (ARTIFICIAL
              INTELLIGENCE AND MACHINE LEARNING), at Chennai Institute of Technology.
            </p>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16pt", marginTop: "20pt" }}>
              <div>
                <p style={{ fontWeight: 700 }}>SIGNATURE</p>
                <p>Dr. R. Gowri, M.E., Ph.D.,</p>
                <p>HEAD OF THE DEPARTMENT</p>
                <p>Department of Computer Science & Engineering, (Artificial Intelligence and Machine Learning)</p>
                <p>Chennai Institute of Technology, Kundrathur, Chennai-600069.</p>
              </div>
              <div>
                <p style={{ fontWeight: 700 }}>SIGNATURE</p>
                <p>Dr. P. Karthikeyan, M.E., Ph.D.,</p>
                <p>Project Coordinator / Associate Professor</p>
                <p>Department of Computer Science & Engineering, (Artificial Intelligence and Machine Learning)</p>
                <p>Chennai Institute of Technology, Kundrathur, Chennai-600069.</p>
              </div>
            </div>

            <p style={{ marginTop: "16pt" }}>
              Certified that the above students have attend of viva voice during the exam held on
              ........................
            </p>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16pt", marginTop: "20pt" }}>
              <div>
                <p style={{ fontWeight: 700 }}>INTERNAL EXAMINER</p>
              </div>
              <div>
                <p style={{ fontWeight: 700 }}>EXTERNAL EXAMINER</p>
              </div>
            </div>
          </section>

          {/* Acknowledgement */}
          <section className="page-break" style={{ paddingTop: "12pt" }}>
            <h3 style={{ fontSize: "14pt", fontWeight: 700 }}>ACKNOWLEDGEMENT</h3>
            <p style={{ whiteSpace: "pre-wrap" }}>{ackText}</p>
            <div style={{ marginTop: "12pt" }}>
              <p>NAME: {student1Name}</p>
              <p>REG.NO: {student1Reg}</p>
              {student2Name ? (
                <>
                  <p>NAME: {student2Name}</p>
                  <p>REG.NO: {student2Reg || ""}</p>
                </>
              ) : null}
            </div>
          </section>

          {/* Abstract */}
          <section className="page-break" style={{ paddingTop: "12pt" }}>
            <h3 style={{ fontSize: "14pt", fontWeight: 700 }}>ABSTRACT</h3>
            <p style={{ whiteSpace: "pre-wrap" }}>{abstractText}</p>
            <p style={{ marginTop: "8pt" }}>
              <strong>Keywords:</strong> {keywords}
            </p>
          </section>

          {/* TOC + Lists */}
          <section className="page-break" style={{ paddingTop: "12pt" }}>
            <h3 style={{ fontSize: "14pt", fontWeight: 700 }}>TABLE OF CONTENTS</h3>
            <ol style={{ marginLeft: "16pt" }}>
              <li>Chapter 1: Introduction</li>
              <li>Chapter 2: Literature Review</li>
              <li>Chapter 3: Methodology</li>
              <li>Chapter 4: Results / Findings</li>
              <li>Chapter 5: Discussion</li>
              <li>Chapter 6: Conclusion</li>
              <li>References</li>
              <li>Appendices</li>
            </ol>

            <h4 style={{ fontSize: "13pt", fontWeight: 700, marginTop: "10pt" }}>List of Figures</h4>
            <ol style={{ marginLeft: "16pt" }}>
              <li>Fig. 1 Grid graph model</li>
              <li>Fig. 2 A* search frontier progression</li>
              <li>Fig. 3 Dijkstra frontier progression</li>
            </ol>

            <h4 style={{ fontSize: "13pt", fontWeight: 700, marginTop: "10pt" }}>List of Tables</h4>
            <ol style={{ marginLeft: "16pt" }}>
              <li>Table 1 Algorithm complexity and metrics</li>
              <li>Table 2 Node expansions with varying obstacle density</li>
            </ol>

            <h4 style={{ fontSize: "13pt", fontWeight: 700, marginTop: "10pt" }}>List of Abbreviations (Optional)</h4>
            <ul style={{ marginLeft: "16pt" }}>
              <li>AI — Artificial Intelligence</li>
              <li>ML — Machine Learning</li>
              <li>R&D — Research & Development</li>
            </ul>
          </section>

          {/* Chapter 1 */}
          <section className="page-break" style={{ paddingTop: "12pt" }}>
            <h3 style={{ fontSize: "14pt", fontWeight: 700 }}>Chapter 1: Introduction</h3>
            <p>
              <strong>Background of the study:</strong> Pathfinding is central to robotics, navigation, and game AI.
              Grid-based search abstracts environments as graphs, enabling algorithmic analysis.
            </p>
            <p>
              <strong>Research problem:</strong> Provide an intuitive, interactive tool to compare A* and Dijkstra,
              illustrating differences in exploration, runtime, and optimality.
            </p>
            <p>
              <strong>Research questions/objectives:</strong> Implement robust A* and Dijkstra; visualize search;
              collect metrics; analyze pedagogical effectiveness.
            </p>
            <p>
              <strong>Significance of the study:</strong> Visual learning accelerates understanding of heuristic search
              and complexity trade-offs.
            </p>
            <p>
              <strong>Scope of the study:</strong> 2D orthogonal grids with non-negative costs; obstacles as walls;
              Manhattan heuristic.
            </p>
            <p>
              <strong>Thesis organization:</strong> Ch.2 prior work, Ch.3 methodology, Ch.4 results, Ch.5 discussion,
              Ch.6 conclusion.
            </p>
          </section>

          {/* Chapter 2 */}
          <section className="page-break" style={{ paddingTop: "12pt" }}>
            <h3 style={{ fontSize: "14pt", fontWeight: 700 }}>Chapter 2: Literature Review</h3>
            <p>
              We review Dijkstra (1959) and A* (Hart, Nilsson, Raphael, 1968), heuristic admissibility/consistency, and
              educational visualization effectiveness for algorithm learning. Many tools lack direct, side-by-side
              comparisons under controlled obstacle densities and speed.
            </p>
            <p>
              <strong>Theoretical foundations:</strong> Shortest path on graphs, heuristic search, admissibility and
              optimality in grid domains.
            </p>
            <p>
              <strong>Gaps in the literature:</strong> Limited instrumentation for metrics and interactive parameter
              tuning in web-based visualizers; our tool addresses these needs.
            </p>
            <p>
              <strong>Research framework:</strong> Grid-graph abstraction; controlled experiments varying wall density
              and start-goal positions.
            </p>
          </section>

          {/* Chapter 3 */}
          <section className="page-break" style={{ paddingTop: "12pt" }}>
            <h3 style={{ fontSize: "14pt", fontWeight: 700 }}>Chapter 3: Methodology</h3>
            <p>
              <strong>Research design (Architecture/Framework):</strong> React-based grid; users place walls, select an
              algorithm, and observe animated expansions.
            </p>
            <p>
              <strong>Data collection methods:</strong> Instrumented counters for visited nodes, path length, and
              elapsed time.
            </p>
            <p>
              <strong>Tools, materials, and procedures:</strong> Next.js App Router, Tailwind CSS, TypeScript; trials at
              varying obstacle densities.
            </p>
            <p>
              <strong>Data analysis methods:</strong> Compare node expansions and runtime across conditions.
            </p>
            <p>
              <strong>Algorithm / Procedure / Pseudo Code:</strong>
            </p>
            <pre style={{ whiteSpace: "pre-wrap", fontFamily: "monospace", fontSize: "10pt", lineHeight: 1.4 }}>
              {`A* (start, goal):
  open <- priority queue by f = g + h
  g[start] = 0; f[start] = h(start, goal)
  while open not empty:
    u <- pop with smallest f
    if u == goal: return reconstruct_path()
    for v in neighbors(u):
      if v is wall: continue
      alt = g[u] + cost(u,v)
      if alt < g[v]:
        g[v] = alt
        f[v] = alt + h(v, goal)
        parent[v] = u
        push v to open

Dijkstra (start, goal):
  dist[*] = INF; dist[start] = 0
  Q <- priority queue by dist
  while Q not empty:
    u <- pop with smallest dist
    if u == goal: return reconstruct_path()
    for v in neighbors(u):
      if v is wall: continue
      alt = dist[u] + cost(u,v)
      if alt < dist[v]:
        dist[v] = alt
        parent[v] = u
        push v to Q`}
            </pre>
            <p>
              <strong>Ethical considerations:</strong> Educational tool; no personal data; open educational usage.
            </p>
          </section>

          {/* Chapter 4 */}
          <section className="page-break" style={{ paddingTop: "12pt" }}>
            <h3 style={{ fontSize: "14pt", fontWeight: 700 }}>Chapter 4: Results / Findings</h3>
            <p>
              Across trials, A* consistently visited fewer nodes than Dijkstra for the same grid configurations,
              reducing runtime while preserving optimality. The effect scales with start-goal distance and obstacle
              placement.
            </p>
            <p>
              <strong>Illustrative Table:</strong>
            </p>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "11pt" }}>
              <thead>
                <tr>
                  <th style={{ border: "1px solid #000", padding: "4pt" }}>Obstacle Density</th>
                  <th style={{ border: "1px solid #000", padding: "4pt" }}>Algorithm</th>
                  <th style={{ border: "1px solid #000", padding: "4pt" }}>Visited Nodes</th>
                  <th style={{ border: "1px solid #000", padding: "4pt" }}>Path Length</th>
                  <th style={{ border: "1px solid #000", padding: "4pt" }}>Runtime (ms)</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td style={{ border: "1px solid #000", padding: "4pt" }}>Low</td>
                  <td style={{ border: "1px solid #000", padding: "4pt" }}>A*</td>
                  <td style={{ border: "1px solid #000", padding: "4pt" }}>120</td>
                  <td style={{ border: "1px solid #000", padding: "4pt" }}>58</td>
                  <td style={{ border: "1px solid #000", padding: "4pt" }}>35</td>
                </tr>
                <tr>
                  <td style={{ border: "1px solid #000", padding: "4pt" }}>Low</td>
                  <td style={{ border: "1px solid #000", padding: "4pt" }}>Dijkstra</td>
                  <td style={{ border: "1px solid #000", padding: "4pt" }}>210</td>
                  <td style={{ border: "1px solid #000", padding: "4pt" }}>58</td>
                  <td style={{ border: "1px solid #000", padding: "4pt" }}>60</td>
                </tr>
              </tbody>
            </table>
          </section>

          {/* Chapter 5 */}
          <section className="page-break" style={{ paddingTop: "12pt" }}>
            <h3 style={{ fontSize: "14pt", fontWeight: 700 }}>Chapter 5: Discussion</h3>
            <p>
              <strong>Interpretation:</strong> Heuristic guidance in A* prunes exploration without sacrificing
              optimality on admissible heuristics. Visual feedback reinforces conceptual understanding.
            </p>
            <p>
              <strong>Comparison with previous research:</strong> Findings align with theory and prior visualization
              studies demonstrating learning gains.
            </p>
            <p>
              <strong>Implications:</strong> Teaching aid for algorithmic thinking, robotics navigation prototypes, and
              level design tools.
            </p>
            <p>
              <strong>Limitations:</strong> Orthogonal grids; no diagonal moves/weights; no dynamic replanning.
            </p>
          </section>

          {/* Chapter 6 */}
          <section className="page-break" style={{ paddingTop: "12pt" }}>
            <h3 style={{ fontSize: "14pt", fontWeight: 700 }}>Chapter 6: Conclusion</h3>
            <p>
              <strong>Summary of key findings:</strong> The web-based visualizer clarifies A* vs. Dijkstra trade-offs
              and confirms expected complexity/optimality behaviors.
            </p>
            <p>
              <strong>Recommendations for future research:</strong> Add diagonal movement, weighted terrains, JPS, IDA*,
              and D* Lite for dynamic environments.
            </p>
            <p>
              <strong>Practical implications:</strong> Enhances pedagogy; informs prototyping in navigation-heavy
              applications.
            </p>
          </section>

          {/* References */}
          <section className="page-break" style={{ paddingTop: "12pt" }}>
            <h3 style={{ fontSize: "14pt", fontWeight: 700 }}>References</h3>
            <ol style={{ marginLeft: "16pt" }}>
              <li>
                Hart, P. E., Nilsson, N. J., and Raphael, B., “A Formal Basis for the Heuristic Determination of Minimum
                Cost Paths,” IEEE Transactions on Systems Science and Cybernetics, 4(2):100–107, 1968.
              </li>
              <li>
                Dijkstra, E. W., “A Note on Two Problems in Connexion with Graphs,” Numerische Mathematik, 1:269–271,
                1959.
              </li>
              <li>Russell, S., and Norvig, P., Artificial Intelligence: A Modern Approach, 4th ed., Pearson, 2021.</li>
              <li>De Berg, M. et al., Computational Geometry: Algorithms and Applications, 3rd ed., Springer, 2008.</li>
            </ol>
          </section>

          {/* Appendices */}
          <section style={{ paddingTop: "12pt" }}>
            <h3 style={{ fontSize: "14pt", fontWeight: 700 }}>Appendices</h3>
            <h4 style={{ fontSize: "13pt", fontWeight: 700, marginTop: "8pt" }}>Appendix A: Selected Code Listings</h4>
            <pre style={{ whiteSpace: "pre-wrap", fontFamily: "monospace", fontSize: "10pt", lineHeight: 1.4 }}>
              {`function manhattan(a, b) {
  return Math.abs(a[0]-b[0]) + Math.abs(a[1]-b[1]);
}

function neighbors(r, c) {
  return [[1,0],[-1,0],[0,1],[0,-1]];
}`}
            </pre>
            <h4 style={{ fontSize: "13pt", fontWeight: 700, marginTop: "8pt" }}>
              Appendix B: Additional Tables/Figures
            </h4>
            <p>Include screenshots of the visualizer runs and extended metric tables as needed.</p>
          </section>
        </div>
      </div>
    </>
  )
}
