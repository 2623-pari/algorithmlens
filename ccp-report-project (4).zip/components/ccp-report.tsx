"use client"

export type ReportData = {
  title: string
  student1Name: string
  student1Reg: string
  student2Name?: string
  student2Reg?: string
  monthYear: string
  department: string
  program: string
  abstract: string
  chapters: { [k: string]: string }
}

export default function CCPReport({ data }: { data: ReportData }) {
  const namesLine = [formatName(data.student1Name, data.student1Reg), formatName(data.student2Name, data.student2Reg)]
    .filter(Boolean)
    .join(", ")

  return (
    <div className="print-area">
      <style jsx global>{`
        @page {
          size: A4;
          margin: 25mm 20mm;
        }
        @media print {
          body * {
            visibility: hidden;
          }
          .print-area,
          .print-area * {
            visibility: visible;
          }
          .print-area {
            position: absolute;
            inset: 0;
            margin: 0;
          }
          .no-print {
            display: none !important;
          }
        }
        .report-root {
          font-family: "Times New Roman", Times, serif;
          line-height: 1.5;
          color: #111827; /* gray-900 */
        }
        .report-root p {
          margin: 0;
        }
        .report-root p + p {
          margin-top: 24pt; /* approx 2 lines at 1.5 leading */
        }
        .page {
          page-break-after: always;
        }
        .page:last-child {
          page-break-after: auto;
        }
        .t-center {
          text-align: center;
        }
        .title {
          font-size: 18pt;
          font-weight: bold;
          text-transform: uppercase;
        }
        .subtitle {
          font-size: 16pt;
          font-weight: bold;
        }
        .small {
          font-size: 12pt;
        }
        .spacer {
          height: 16pt;
        }
      `}</style>

      <div className="report-root">
        {/* Title Page */}
        <section className="page">
          <div className="t-center">
            <div className="title">{data.title}</div>
            <div className="spacer" />
            <div className="subtitle">A CORE COURSE PROJECT REPORT</div>
            <div className="spacer" />
            <p className="small">Submitted by</p>
            <p className="small">{namesLine}</p>
            <div className="spacer" />
            <p className="small">in partial fulfillment for the award of the degree of</p>
            <div className="subtitle">BACHELOR OF ENGINEERING</div>
            <div className="spacer" />
            <div className="subtitle">in</div>
            <div className="subtitle">{data.program}</div>
            <div className="spacer" />
            <p className="small">CHENNAI INSTITUTE OF TECHNOLOGY (AUTONOMOUS)</p>
            <p className="small">(Affiliated to Anna University, Chennai)</p>
            <p className="small">CHENNAI-600 069</p>
            <p className="small">ANNA UNIVERSITY: CHENNAI-600 025</p>
            <div className="spacer" />
            <p className="small">{data.monthYear}</p>
          </div>
        </section>

        {/* Vision & Mission */}
        <section className="page">
          <div className="t-center subtitle">Vision of the Institute:</div>
          <div className="spacer" />
          <p>
            To be an eminent centre for Academia, Industry and Research by imparting knowledge, relevant practices and
            inculcating human values to address global challenges through novelty and sustainability.
          </p>
          <div className="spacer" />
          <div className="subtitle">Mission of the Institute:</div>
          <div className="spacer" />
          <p>
            IM1: To create next generation leaders by effective teaching learning methodologies and instill scientific
            spark in them to meet the global challenges.
          </p>
          <p>IM2: To transform lives through deployment of emerging technology, novelty and Sustainability.</p>
          <p>IM3: To inculcate human values and ethical principles to cater to the societal needs.</p>
          <p>
            IM4: To contribute towards the research ecosystem by providing a suitable, effective platform for
            interaction between industry, academia and R & D establishments.
          </p>
          <p>IM5: To nurture incubation centers enabling structured entrepreneurship and start-ups.</p>
          <div className="spacer" />
          <div className="subtitle">Vision of the Department:</div>
          <div className="spacer" />
          <p>
            Developing talented professionals in the fields of AI and ML that contribute to the benefit of business
            enterprise and societies around the world.
          </p>
          <div className="spacer" />
          <div className="subtitle">Mission of the Department:</div>
          <div className="spacer" />
          <p>
            DM1: To broaden kingdom of the art instructional and infrastructural facilities with current equipment and
            different gaining knowledge of assets to provide self-sustainable specialists.
          </p>
          <p>
            DM2: To collaborate with enterprise and research Laboratories thru tasks-primarily based mastering,
            internships permitting the students to discover, apply diverse guidelines of learning.
          </p>
          <p>
            DM3: To establish value creating networks and linkages with company, industries, academic institutes and
            universities of countrywide and global significance.
          </p>
          <p>
            DM4: To equip students with interdisciplinary talent units to build intelligent structures which in flip
            affords dynamic and promising careers inside the worldwide marketplace.
          </p>
          <div className="spacer" />
          <p className="t-center small">CHENNAI INSTITUTE OF TECHNOLOGY • An Autonomous Institute • CHENNAI-69</p>
        </section>

        {/* Bonafide Certificate */}
        <section className="page">
          <div className="t-center subtitle">ANNA UNIVERSITY: CHENNAI-600 025</div>
          <div className="spacer" />
          <div className="t-center subtitle">BONAFIDE CERTIFICATE</div>
          <div className="spacer" />
          <p>
            Certified that this Core Course project report “{data.title}” Submitted by {namesLine} is a work done by
            him/her and submitted during 2025-2026 academic year, in partial fulfillment of the requirements for the
            award of the degree of BACHELOR OF ENGINEERING in DEPARTMENT OF CSE (ARTIFICIAL INTELLIGENCE AND MACHINE
            LEARNING), at Chennai Institute of Technology.
          </p>
          <div className="spacer" />
          <div className="grid grid-cols-2 gap-8 small">
            <div>
              <div>SIGNATURE</div>
              <div>Dr.R.Gowri, M.E., Ph.D.,</div>
              <div>HEAD OF THE DEPARTMENT</div>
              <div>Professor</div>
              <div>Department of Computer Science & Engineering, (Artificial Intelligence and Machine Learning)</div>
              <div>Chennai Institute of Technology, Kundrathur, Chennai-600069.</div>
            </div>
            <div>
              <div>SIGNATURE</div>
              <div>Dr.P.Karthikeyan, M.E., Ph.D.,</div>
              <div>Project Coordinator</div>
              <div>Associate Professor</div>
              <div>Department of Computer Science & Engineering, (Artificial Intelligence and Machine Learning)</div>
              <div>Chennai Institute of Technology, Kundrathur, Chennai-600069.</div>
            </div>
          </div>
          <div className="spacer" />
          <p>
            Certified that the above students have attend of viva voice during the exam held on........................
          </p>
          <div className="spacer" />
          <div className="grid grid-cols-2 gap-8 small">
            <div>INTERNAL EXAMINER</div>
            <div>EXTERNAL EXAMINER</div>
          </div>
        </section>

        {/* Acknowledgement */}
        <section className="page">
          <div className="t-center subtitle">ACKNOWLEDGEMENT</div>
          <div className="spacer" />
          <p>
            We express our gratitude to our Chairman Shri.P. SRIRAM and all trust members of Chennai institute of
            technology for providing the facility and opportunity to do this project as a part of our undergraduate
            course.
          </p>
          <p>
            We are grateful to our Principal Dr.A.RAMESH M.E., Ph.D., for providing us the facility and encouragement
            during the course of our work.
          </p>
          <p>
            We sincerely thank our Head of the Department, Dr.R.Gowri, M.E., Ph.D., Department of Computer Science and
            Engineering, (Artificial Intelligence and Machine Learning) for having provided us valuable guidance,
            resources and timely suggestions throughout our work.
          </p>
          <p>
            We sincerely thank our Core Course Project Guide, Dr.P.Karthikeyan M.E., Ph.D., Associate Professor,
            Department of Computer Science and Engineering, (Artificial Intelligence and Machine Learning) for having
            provided us valuable guidance, resources and timely suggestions throughout our work.
          </p>
          <p>
            We would like to extend our thanks to our Faculty coordinators of the Department of Computer Science and
            Engineering, (Artificial Intelligence and Machine Learning), for their valuable suggestions throughout this
            project.
          </p>
          <p>
            We wish to extend our sincere thanks to all Faculty members of the Department of Computer Science and
            Engineering, (Artificial Intelligence and Machine Learning) for their valuable suggestions and their kind
            cooperation for the successful completion of our project.
          </p>
          <p>
            We wish to acknowledge the help received from the Lab Instructors of the Department of Computer Science and
            Engineering, (Artificial Intelligence and Machine Learning) and others for providing valuable suggestions
            and for the successful completion of the project.
          </p>

          <div className="spacer" />
          <p>
            NAME:&nbsp;&nbsp;{data.student1Name}&nbsp;&nbsp;&nbsp;REG.NO:&nbsp;{data.student1Reg}
          </p>
          {data.student2Name && data.student2Reg ? (
            <p>
              NAME:&nbsp;&nbsp;{data.student2Name}&nbsp;&nbsp;&nbsp;REG.NO:&nbsp;{data.student2Reg}
            </p>
          ) : null}
        </section>

        {/* Abstract */}
        <section className="page">
          <div className="t-center subtitle">ABSTRACT</div>
          <div className="spacer" />
          <p>{data.abstract}</p>
        </section>

        {/* Chapters (1..6) */}
        {[
          "Chapter 1: Introduction",
          "Chapter 2: Literature Review",
          "Chapter 3: Methodology",
          "Chapter 4: Results/Findings",
          "Chapter 5: Discussion",
          "Chapter 6: Conclusion",
        ].map((ch) => (
          <section key={ch} className="page">
            <div className="subtitle">{ch}</div>
            <div className="spacer" />
            <p>{data.chapters[ch] || "Content to be filled as per project."}</p>
          </section>
        ))}

        {/* References */}
        <section className="page">
          <div className="subtitle">References</div>
          <div className="spacer" />
          <p>
            List all sources cited (IEEE preferred). Example: A. Author, “Paper Title,” Conference/Journal, Year, pp.
            xx–yy.
          </p>
        </section>

        {/* Appendices */}
        <section className="page">
          <div className="subtitle">Appendices (Optional)</div>
          <div className="spacer" />
          <p>Include code listings, questionnaires, raw data, or additional figures/tables as needed.</p>
        </section>
      </div>
    </div>
  )
}

function formatName(name?: string, reg?: string) {
  if (!name || !reg) return ""
  return `${name} ${reg}`
}
