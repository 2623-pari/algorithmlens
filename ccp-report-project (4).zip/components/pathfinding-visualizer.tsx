"use client"

import { useEffect, useRef, useState } from "react"
import { Button } from "@/components/ui/button"

type Cell = {
  r: number
  c: number
  wall: boolean
  visited: boolean
  inPath: boolean
}

type Algo = "astar" | "dijkstra"

const GRID_ROWS = 20
const GRID_COLS = 30

function makeGrid(): Cell[][] {
  const grid: Cell[][] = []
  for (let r = 0; r < GRID_ROWS; r++) {
    const row: Cell[] = []
    for (let c = 0; c < GRID_COLS; c++) {
      row.push({ r, c, wall: false, visited: false, inPath: false })
    }
    grid.push(row)
  }
  return grid
}

function manhattan(a: [number, number], b: [number, number]) {
  return Math.abs(a[0] - b[0]) + Math.abs(a[1] - b[1])
}

function neighbors(r: number, c: number) {
  const dirs = [
    [1, 0],
    [-1, 0],
    [0, 1],
    [0, -1],
  ]
  const out: [number, number][] = []
  for (const [dr, dc] of dirs) {
    const nr = r + dr
    const nc = c + dc
    if (nr >= 0 && nr < GRID_ROWS && nc >= 0 && nc < GRID_COLS) out.push([nr, nc])
  }
  return out
}

type Step = { r: number; c: number; type: "visit" | "path" }

export default function PathfindingVisualizer() {
  const [grid, setGrid] = useState<Cell[][]>(makeGrid)
  const [start, setStart] = useState<[number, number]>([0, 0])
  const [goal, setGoal] = useState<[number, number]>([GRID_ROWS - 1, GRID_COLS - 1])
  const [algo, setAlgo] = useState<Algo>("astar")
  const [isMouseDown, setIsMouseDown] = useState(false)
  const [animSpeed, setAnimSpeed] = useState(60)
  const animRef = useRef<number | null>(null)

  useEffect(() => {
    return () => {
      if (animRef.current) window.clearInterval(animRef.current)
    }
  }, [])

  function toggleWall(r: number, c: number) {
    if ((r === start[0] && c === start[1]) || (r === goal[0] && c === goal[1])) return
    setGrid((g) => {
      const copy = g.map((row) => row.map((cell) => ({ ...cell })))
      copy[r][c].wall = !copy[r][c].wall
      return copy
    })
  }

  function clearVisits() {
    setGrid((g) => g.map((row) => row.map((cell) => ({ ...cell, visited: false, inPath: false }))))
  }

  function clearAll() {
    setGrid(makeGrid())
  }

  function reconstructPath(prev: Map<string, string>, endKey: string): Step[] {
    const pathSteps: Step[] = []
    let cur = endKey
    while (prev.has(cur)) {
      const [r, c] = cur.split(",").map(Number)
      pathSteps.push({ r, c, type: "path" })
      cur = prev.get(cur)!
    }
    return pathSteps.reverse()
  }

  function runDijkstra(): Step[] {
    const steps: Step[] = []
    const pq: Array<{ key: string; dist: number }> = []
    const dist = new Map<string, number>()
    const prev = new Map<string, string>()
    const walls = new Set<string>()

    for (const row of grid)
      for (const cell of row) {
        const key = `${cell.r},${cell.c}`
        if (cell.wall) walls.add(key)
        dist.set(key, Number.POSITIVE_INFINITY)
      }

    const startKey = `${start[0]},${start[1]}`
    const goalKey = `${goal[0]},${goal[1]}`
    dist.set(startKey, 0)
    pq.push({ key: startKey, dist: 0 })

    const popMin = () => {
      let idx = 0
      for (let i = 1; i < pq.length; i++) if (pq[i].dist < pq[idx].dist) idx = i
      return pq.splice(idx, 1)[0]
    }

    while (pq.length) {
      const { key, dist: d } = popMin()
      const [r, c] = key.split(",").map(Number)
      if (walls.has(key)) continue
      steps.push({ r, c, type: "visit" })
      if (key === goalKey) {
        const path = reconstructPath(prev, key)
        return [...steps, ...path]
      }
      for (const [nr, nc] of neighbors(r, c)) {
        const nk = `${nr},${nc}`
        if (walls.has(nk)) continue
        const nd = d + 1
        if (nd < (dist.get(nk) ?? Number.POSITIVE_INFINITY)) {
          dist.set(nk, nd)
          prev.set(nk, key)
          pq.push({ key: nk, dist: nd })
        }
      }
    }
    return steps
  }

  function runAStar(): Step[] {
    const steps: Step[] = []
    const open: Array<{ key: string; f: number; g: number }> = []
    const gScore = new Map<string, number>()
    const fScore = new Map<string, number>()
    const prev = new Map<string, string>()
    const walls = new Set<string>()

    for (const row of grid)
      for (const cell of row) {
        const key = `${cell.r},${cell.c}`
        if (cell.wall) walls.add(key)
        gScore.set(key, Number.POSITIVE_INFINITY)
        fScore.set(key, Number.POSITIVE_INFINITY)
      }

    const startKey = `${start[0]},${start[1]}`
    const goalKey = `${goal[0]},${goal[1]}`
    gScore.set(startKey, 0)
    fScore.set(startKey, manhattan(start, goal))
    open.push({ key: startKey, g: 0, f: fScore.get(startKey)! })

    const popMin = () => {
      let idx = 0
      for (let i = 1; i < open.length; i++) if (open[i].f < open[idx].f) idx = i
      return open.splice(idx, 1)[0]
    }

    while (open.length) {
      const { key, g } = popMin()
      const [r, c] = key.split(",").map(Number)
      if (walls.has(key)) continue
      steps.push({ r, c, type: "visit" })
      if (key === goalKey) {
        const path = reconstructPath(prev, key)
        return [...steps, ...path]
      }
      for (const [nr, nc] of neighbors(r, c)) {
        const nk = `${nr},${nc}`
        if (walls.has(nk)) continue
        const tentativeG = g + 1
        if (tentativeG < (gScore.get(nk) ?? Number.POSITIVE_INFINITY)) {
          gScore.set(nk, tentativeG)
          prev.set(nk, key)
          const f = tentativeG + manhattan([nr, nc], goal)
          fScore.set(nk, f)
          open.push({ key: nk, g: tentativeG, f })
        }
      }
    }
    return steps
  }

  function animate(steps: Step[]) {
    const copy = grid.map((row) => row.map((cell) => ({ ...cell, visited: false, inPath: false })))
    setGrid(copy)
    let i = 0
    if (animRef.current) window.clearInterval(animRef.current)
    animRef.current = window.setInterval(() => {
      if (i >= steps.length) {
        window.clearInterval(animRef.current!)
        animRef.current = null
        return
      }
      const s = steps[i++]
      setGrid((g) => {
        const next = g.map((row) => row.map((cell) => ({ ...cell })))
        if (s.type === "visit") next[s.r][s.c].visited = true
        else if (s.type === "path") next[s.r][s.c].inPath = true
        return next
      })
    }, animSpeed)
  }

  function run() {
    const steps = algo === "astar" ? runAStar() : runDijkstra()
    animate(steps)
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-3">
        <label className="text-sm">
          Algorithm:&nbsp;
          <select
            className="rounded-md border border-gray-300 px-2 py-1 text-sm"
            value={algo}
            onChange={(e) => setAlgo(e.target.value as Algo)}
          >
            <option value="astar">A*</option>
            <option value="dijkstra">Dijkstra</option>
          </select>
        </label>

        <label className="flex items-center gap-2 text-sm">
          Speed:{" "}
          <input
            type="range"
            min={10}
            max={200}
            step={10}
            value={animSpeed}
            onChange={(e) => setAnimSpeed(Number.parseInt(e.target.value))}
          />
          <span className="text-xs text-muted-foreground">{animSpeed} ms</span>
        </label>

        <Button onClick={run}>Run</Button>
        <Button variant="secondary" onClick={clearVisits}>
          Clear Visits
        </Button>
        <Button variant="destructive" onClick={clearAll}>
          Reset Grid
        </Button>
      </div>

      <div className="select-none rounded-md border" onMouseLeave={() => setIsMouseDown(false)}>
        {grid.map((row, ri) => (
          <div key={ri} className="flex">
            {row.map((cell) => {
              const isStart = cell.r === start[0] && cell.c === start[1]
              const isGoal = cell.r === goal[0] && cell.c === goal[1]
              return (
                <div
                  key={`${cell.r}-${cell.c}`}
                  onMouseDown={() => {
                    setIsMouseDown(true)
                    toggleWall(cell.r, cell.c)
                  }}
                  onMouseUp={() => setIsMouseDown(false)}
                  onMouseEnter={() => {
                    if (isMouseDown) toggleWall(cell.r, cell.c)
                  }}
                  className="h-6 w-6 border-b border-r last:border-r-0"
                  style={{
                    backgroundColor: cell.wall
                      ? "#111827" // wall
                      : cell.inPath
                        ? "#10b981" // path
                        : cell.visited
                          ? "#93c5fd" // visited
                          : "#ffffff",
                  }}
                  title={isStart ? "Start" : isGoal ? "Goal" : undefined}
                >
                  {isStart ? (
                    <div className="h-full w-full bg-blue-600/90" />
                  ) : isGoal ? (
                    <div className="h-full w-full bg-red-500/90" />
                  ) : null}
                </div>
              )
            })}
          </div>
        ))}
      </div>

      <div className="flex items-center gap-3 text-sm text-muted-foreground">
        <span className="inline-flex h-3 w-3 bg-blue-600" /> Start
        <span className="inline-flex h-3 w-3 bg-red-500" /> Goal
        <span className="inline-flex h-3 w-3 bg-[#93c5fd]" /> Visited
        <span className="inline-flex h-3 w-3 bg-[#10b981]" /> Path
        <span className="inline-flex h-3 w-3 bg-[#111827]" /> Wall
      </div>
    </div>
  )
}
