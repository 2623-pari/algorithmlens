"use client"

import { useMemo, useState, useCallback, lazy, Suspense } from "react"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Button } from "@/components/ui/button"
import type { Student } from "./report-print"

const ReportPrint = lazy(() => import("./report-print"))

type Chapter = {
  title: string
  content: string
}

export default function ReportBuilder() {
  const [title, setTitle] = useState("A CORE COURSE PROJECT REPORT")
  const [projectTitle, setProjectTitle] = useState(
    "AlgoLens: An Intelligent Algorithm Recommendation and Visualization System",
  )
  const [students, setStudents] = useState<Student[]>([{ name: "Lavanyaa", regNo: "A22AM024" }])
  const [month, setMonth] = useState("OCTOBER")
  const [year, setYear] = useState("2025")
  const [abstractText, setAbstractText] = useState(
    "This Core Course Project presents AlgoLens, an intelligent algorithm recommendation and visualization system that unifies Machine Learning (ML), Design & Analysis of Algorithms (DAA), and a modern Web framework into a single learning and decision-support tool. AlgoLens accepts problem configurations (e.g., array length, duplicates, partial order for sorting; grid density and heuristic availability for pathfinding) and recommends a suitable algorithm, then animates the algorithm's execution for conceptual clarity. For sorting, AlgoLens considers QuickSort, MergeSort, HeapSort, and InsertionSort; for pathfinding, it compares Dijkstra and A*. The system juxtaposes theoretical complexity with empirical behavior (visited nodes, runtime surrogates, path length) to build intuition about trade-offs such as optimality, stability, and extra space.\n\nThe platform is implemented with React/Next.js for the interactive UI and animation, and a pluggable recommender that can be rule-based (for demonstration) or replaced with a trained ML model. We provide pseudo code and design details for each algorithm, instrument the execution to collect metrics, and discuss the implications of heuristics, input distribution, and data structure choices. Results show that the recommender's guidance aligns with expected theory (e.g., A* typically expands fewer nodes than Dijkstra when the heuristic is admissible; InsertionSort excels on small or nearly sorted inputs; MergeSort sustains stability) while the visualization improves learner comprehension. The work concludes with future scope for richer datasets, additional algorithms, and a production-grade ML model.",
  )
  const [ackText, setAckText] = useState(
    "We extend our sincere gratitude to the management, Principal, HoD, faculty, and our guide for their continuous support, constructive feedback, and encouragement throughout the project.",
  )

  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false)
  const [showPreview, setShowPreview] = useState(false)

  const [chapters, setChapters] = useState<Chapter[]>([
    {
      title: "Chapter 1: Introduction",
      content:
        "Background: Selecting the right algorithm for a given input distribution is crucial for performance and correctness. Problem: Learners often struggle to connect theoretical complexity with practical outcomes and to justify algorithm choice. Objectives: (1) Recommend suitable algorithms for Sorting and Pathfinding given input conditions, (2) visualize step-by-step execution, (3) compare theoretical vs. empirical behavior, and (4) discuss trade-offs (time/space/stability/optimality). Significance: Integrates ML (recommender), DAA (analysis and proofs), and a Web framework (interactive visualization) into one pedagogical tool. Scope: Sorting (QuickSort, MergeSort, HeapSort, InsertionSort) and Pathfinding (Dijkstra, A*) on representative inputs. Organization: Chapter 2 reviews related work; Chapter 3 explains architecture, algorithms, and pseudo code; Chapter 4 presents findings; Chapter 5 discusses implications and limits; Chapter 6 concludes and outlines future scope.",
    },
    {
      title: "Chapter 2: Literature Review",
      content:
        "We survey algorithm selection and performance modeling, including empirical studies on sorting under varied distributions (duplicates, partial order) and pathfinding with admissible heuristics (A* vs. Dijkstra). We review meta-learning for algorithm recommendation, stability in sorting (MergeSort), QuickSort's average vs. worst case, and teaching tools for algorithm animation. Gaps: existing visualizers rarely couple a principled recommendation layer with a formal, print-ready academic report workflow.",
    },
    {
      title: "Chapter 3: Methodology",
      content:
        "Architecture: React/Next.js UI, parameter controls, and animation canvas; a recommender module (rule-based proxy now, ML model pluggable later); algorithm engines for Sorting and Pathfinding; metrics collection; and a report generator. Data & Inputs: arrays of configurable size/duplicates/partial order; grids with adjustable obstacle density and heuristic availability. Tools: TypeScript, TailwindCSS. Analysis: compare O-notated complexity against measured visitation counts and qualitative runtime surrogates. Pseudo Code: include concise versions for QuickSort/MergeSort/HeapSort/InsertionSort, Dijkstra, and A*. Ethics: academic integrity, transparent methodology, and reproducibility of experiments.",
    },
    {
      title: "Chapter 4: Results/Findings",
      content:
        "Across varied parameters, the recommender aligns with expected theory: InsertionSort excels on small or nearly sorted inputs; MergeSort offers stability; HeapSort provides predictable O(n log n); QuickSort shines on large random arrays. For Pathfinding, with an admissible heuristic, A* typically explores fewer nodes than Dijkstra at comparable solution quality. Visual metrics (visited nodes, path length) and qualitative runtime surrogates substantiate these trends.",
    },
    {
      title: "Chapter 5: Discussion",
      content:
        "Interpretation: The coupling of recommendation + visualization improves learner intuition and justifies algorithm choice with evidence. Trade-offs: stability vs. space (MergeSort), average vs. worst-case behavior (QuickSort), and guidance vs. uniform exploration (A* vs. Dijkstra). Limitations: current prototype uses a rule-based recommender; graphs are grid-based with unit weights; no I/O-heavy datasets. Generalization: Framework can extend to searching, DP, string algorithms, and weighted terrains.",
    },
    {
      title: "Chapter 6: Conclusion",
      content:
        "We proposed AlgoLens and demonstrated that a combined recommender + visualizer helps bridge DAA theory and practice. The system generates explainable choices and animations that reinforce understanding. Future Work: integrate a trained ML model (e.g., Random Forest or SVM) for recommendation, add more algorithms/datasets, include runtime measurement and memory profiling, support diagonal/weighted pathfinding, and export richer analytics in the report.",
    },
  ])

  const addStudent = useCallback(() => {
    setStudents((s) => [...s, { name: "", regNo: "" }])
  }, [])

  const removeStudent = useCallback((idx: number) => {
    setStudents((s) => s.filter((_, i) => i !== idx))
  }, [])

  const updateStudent = useCallback((idx: number, field: keyof Student, value: string) => {
    setStudents((all) => all.map((x, i) => (i === idx ? { ...x, [field]: value } : x)))
  }, [])

  const updateChapter = useCallback((idx: number, field: keyof Chapter, value: string) => {
    setChapters((arr) => arr.map((c, i) => (i === idx ? { ...c, [field]: value } : c)))
  }, [])

  const handlePrintPdf = useCallback(async () => {
    setIsGeneratingPdf(true)
    setShowPreview(true)

    // Small delay to ensure preview renders
    setTimeout(() => {
      window.print()
      setIsGeneratingPdf(false)
    }, 100)
  }, [])

  const reportData = useMemo(
    () => ({
      title,
      projectTitle,
      students,
      month,
      year,
      abstractText,
      ackText,
      chapters,
    }),
    [title, projectTitle, students, month, year, abstractText, ackText, chapters],
  )

  return (
    <div className="flex flex-col gap-6">
      <section className="grid grid-cols-1 gap-4 md:grid-cols-2">
        <div className="space-y-3">
          <label className="block text-sm font-medium">Report Title (18pt)</label>
          <Input value={title} onChange={(e) => setTitle(e.target.value)} />
        </div>
        <div className="space-y-3">
          <label className="block text-sm font-medium">Project TITLE</label>
          <Input value={projectTitle} onChange={(e) => setProjectTitle(e.target.value)} />
        </div>
      </section>

      <section className="space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="font-medium">Submitted by (Name and Register Number)</h3>
          <Button variant="secondary" onClick={addStudent}>
            Add Student
          </Button>
        </div>
        <div className="space-y-3">
          {students.map((s, idx) => (
            <div key={idx} className="grid grid-cols-1 gap-3 md:grid-cols-5">
              <div className="md:col-span-2">
                <Input placeholder="Name" value={s.name} onChange={(e) => updateStudent(idx, "name", e.target.value)} />
              </div>
              <div className="md:col-span-2">
                <Input
                  placeholder="Register Number"
                  value={s.regNo}
                  onChange={(e) => updateStudent(idx, "regNo", e.target.value)}
                />
              </div>
              <div className="flex items-center justify-end">
                {students.length > 1 && (
                  <Button variant="destructive" onClick={() => removeStudent(idx)}>
                    Remove
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="grid grid-cols-1 gap-4 md:grid-cols-2">
        <div className="space-y-3">
          <label className="block text-sm font-medium">Month</label>
          <Input value={month} onChange={(e) => setMonth(e.target.value)} />
        </div>
        <div className="space-y-3">
          <label className="block text-sm font-medium">Year</label>
          <Input value={year} onChange={(e) => setYear(e.target.value)} />
        </div>
      </section>

      <section className="space-y-3">
        <label className="block text-sm font-medium">Abstract</label>
        <Textarea rows={6} value={abstractText} onChange={(e) => setAbstractText(e.target.value)} />
      </section>

      <section className="space-y-3">
        <label className="block text-sm font-medium">Acknowledgement</label>
        <Textarea rows={6} value={ackText} onChange={(e) => setAckText(e.target.value)} />
      </section>

      <section className="space-y-4">
        <h3 className="font-medium">Chapters</h3>
        {chapters.map((ch, idx) => (
          <div key={idx} className="space-y-2">
            <Input value={ch.title} onChange={(e) => updateChapter(idx, "title", e.target.value)} />
            <Textarea rows={5} value={ch.content} onChange={(e) => updateChapter(idx, "content", e.target.value)} />
          </div>
        ))}
      </section>

      <hr className="my-2" />

      <div className="flex items-center justify-between gap-2 no-print">
        <Button variant="outline" onClick={() => setShowPreview(!showPreview)} className="text-sm">
          {showPreview ? "Hide Preview" : "Show Preview"}
        </Button>
        <Button onClick={handlePrintPdf} disabled={isGeneratingPdf} className="bg-blue-600 text-white">
          {isGeneratingPdf ? "Generating PDF..." : "Download PDF (Print)"}
        </Button>
      </div>

      {showPreview && (
        <section className="rounded-md border bg-white">
          <Suspense
            fallback={
              <div className="flex items-center justify-center p-8">
                <div className="text-gray-500">Loading report preview...</div>
              </div>
            }
          >
            <ReportPrint data={reportData} />
          </Suspense>
        </section>
      )}
    </div>
  )
}
