"use client"

import { useEffect, useMemo, useRef, useState } from "react"

type ProblemType = "Sorting" | "Pathfinding"
type SortingAlgo = "QuickSort" | "MergeSort" | "HeapSort" | "InsertionSort"
type PathAlgo = "Dijkstra" | "A*"

export default function AlgoLens() {
  const [problemType, setProblemType] = useState<ProblemType>("Sorting")

  // Sorting
  const [n, setN] = useState(30)
  const [duplicates, setDuplicates] = useState(true)
  const [partiallySorted, setPartiallySorted] = useState(false)
  const [sortingAlgo, setSortingAlgo] = useState<SortingAlgo | null>(null)
  const [arr, setArr] = useState<number[]>([])
  const [isSorting, setIsSorting] = useState(false)
  const [highlight, setHighlight] = useState<number | null>(null)

  // Pathfinding
  const [rows] = useState(12)
  const [cols] = useState(18)
  const [density, setDensity] = useState(0.2)
  const [hasHeuristic, setHasHeuristic] = useState(true)
  const [pathAlgo, setPathAlgo] = useState<PathAlgo | null>(null)
  const [grid, setGrid] = useState<number[][]>([])
  const [start] = useState<{ r: number; c: number }>({ r: 1, c: 1 })
  const [goal] = useState<{ r: number; c: number }>({ r: 10, c: 16 })
  const [animating, setAnimating] = useState(false)
  const visitedRef = useRef<Set<string>>(new Set())
  const pathRef = useRef<Set<string>>(new Set())

  // Backend recommendation (optional)
  const [apiRec, setApiRec] = useState<{ algorithms: string[]; rationale: string } | null>(null)
  async function askBackend(pt: "Sorting" | "Pathfinding") {
    try {
      const res = await fetch("/api/recommend", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ problemType: pt }),
      })
      if (!res.ok) throw new Error("Request failed")
      const json = await res.json()
      if (json?.recommendation) setApiRec(json.recommendation)
    } catch (e) {
      setApiRec({ algorithms: ["Clarify constraints"], rationale: "Backend not reachable or invalid request." })
    }
  }

  // Init
  useEffect(() => {
    regenerateArray()
  }, [n, duplicates, partiallySorted])

  useEffect(() => {
    regenerateGrid()
  }, [rows, cols, density])

  function regenerateArray() {
    const base = Array.from({ length: n }, (_, i) => i + 1)
    let generated: number[] = []
    if (duplicates) {
      generated = base.map((v) => Math.floor((v % 10) + 1))
    } else {
      generated = base.slice()
    }
    for (let i = generated.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1))
      ;[generated[i], generated[j]] = [generated[j], generated[i]]
    }
    if (partiallySorted) {
      const half = Math.floor(generated.length / 2)
      const left = generated.slice(0, half).sort((a, b) => a - b)
      const right = generated.slice(half)
      generated = left.concat(right)
    }
    setArr(generated)
  }

  function regenerateGrid() {
    const g = Array.from({ length: rows }, () => Array.from({ length: cols }, () => (Math.random() < density ? 1 : 0)))
    g[start.r][start.c] = 0
    g[goal.r][goal.c] = 0
    setGrid(g)
    visitedRef.current = new Set()
    pathRef.current = new Set()
  }

  // Recommenders (rule-based proxy for ML)
  function recommendSorting(): SortingAlgo {
    if (n <= 25 || partiallySorted) return "InsertionSort"
    if (duplicates) return "MergeSort"
    if (n >= 80) return "HeapSort"
    return "QuickSort"
  }
  function recommendPath(): PathAlgo {
    if (hasHeuristic && density < 0.4) return "A*"
    return "Dijkstra"
  }

  const recommendedSorting = useMemo(() => recommendSorting(), [n, duplicates, partiallySorted])
  const recommendedPath = useMemo(() => recommendPath(), [density, hasHeuristic])

  // Sorting logic
  const barMax = useMemo(() => Math.max(1, ...arr), [arr])
  async function runSort(algo: SortingAlgo) {
    if (isSorting) return
    setIsSorting(true)
    const data = arr.slice()
    const delay = (ms: number) => new Promise((res) => setTimeout(res, ms))
    const swap = (i: number, j: number) => {
      ;[data[i], data[j]] = [data[j], data[i]]
    }

    if (algo === "InsertionSort") {
      for (let i = 1; i < data.length; i++) {
        const key = data[i]
        let j = i - 1
        while (j >= 0 && data[j] > key) {
          data[j + 1] = data[j]
          j--
          setArr(data.slice())
          setHighlight(j)
          await delay(20)
        }
        data[j + 1] = key
        setArr(data.slice())
        await delay(20)
      }
    } else if (algo === "QuickSort") {
      async function qs(l: number, r: number): Promise<void> {
        if (l >= r) return
        const pivot = data[r]
        let i = l
        for (let j = l; j < r; j++) {
          if (data[j] < pivot) {
            swap(i, j)
            i++
            setArr(data.slice())
            setHighlight(j)
            await delay(15)
          }
        }
        swap(i, r)
        setArr(data.slice())
        await delay(15)
        await qs(l, i - 1)
        await qs(i + 1, r)
      }
      await qs(0, data.length - 1)
    } else if (algo === "MergeSort") {
      async function merge(l: number, m: number, r: number) {
        const left = data.slice(l, m + 1)
        const right = data.slice(m + 1, r + 1)
        let i = 0,
          j = 0,
          k = l
        while (i < left.length && j < right.length) {
          if (left[i] <= right[j]) data[k++] = left[i++]
          else data[k++] = right[j++]
          setArr(data.slice())
          setHighlight(k)
          await delay(20)
        }
        while (i < left.length) {
          data[k++] = left[i++]
          setArr(data.slice())
          await delay(15)
        }
        while (j < right.length) {
          data[k++] = right[j++]
          setArr(data.slice())
          await delay(15)
        }
      }
      async function ms(l: number, r: number): Promise<void> {
        if (l >= r) return
        const m = Math.floor((l + r) / 2)
        await ms(l, m)
        await ms(m + 1, r)
        await merge(l, m, r)
      }
      await ms(0, data.length - 1)
    } else if (algo === "HeapSort") {
      function heapify(nh: number, i: number) {
        let largest = i
        const left = 2 * i + 1
        const right = 2 * i + 2
        if (left < nh && data[left] > data[largest]) largest = left
        if (right < nh && data[right] > data[largest]) largest = right
        if (largest !== i) {
          ;[data[i], data[largest]] = [data[largest], data[i]]
          heapify(nh, largest)
        }
      }
      for (let i = Math.floor(data.length / 2) - 1; i >= 0; i--) heapify(data.length, i)
      for (let i = data.length - 1; i > 0; i--) {
        ;[data[0], data[i]] = [data[i], data[0]]
        heapify(i, 0)
        setArr(data.slice())
        setHighlight(i)
        await new Promise((r) => setTimeout(r, 20))
      }
    }
    setArr(data.slice())
    setHighlight(null)
    setIsSorting(false)
  }

  // Pathfinding logic (A* / Dijkstra on 4-neighborhood grid)
  function key(r: number, c: number) {
    return `${r}:${c}`
  }
  const dirs = [
    [1, 0],
    [-1, 0],
    [0, 1],
    [0, -1],
  ]
  function heuristic(a: { r: number; c: number }, b: { r: number; c: number }) {
    return Math.abs(a.r - b.r) + Math.abs(a.c - b.c)
  }

  async function runPathfinding(algo: PathAlgo) {
    if (animating) return
    setAnimating(true)
    visitedRef.current = new Set()
    pathRef.current = new Set()

    const open: Array<{ r: number; c: number }> = [start]
    const came = new Map<string, string>()
    const gScore = new Map<string, number>()
    const fScore = new Map<string, number>()
    gScore.set(key(start.r, start.c), 0)
    fScore.set(key(start.r, start.c), heuristic(start, goal))

    const delay = (ms: number) => new Promise((res) => setTimeout(res, ms))
    function neighbors(r: number, c: number) {
      const nb: Array<{ r: number; c: number }> = []
      for (const [dr, dc] of dirs) {
        const nr = r + dr,
          nc = c + dc
        if (nr >= 0 && nr < rows && nc >= 0 && nc < cols && grid[nr][nc] === 0) nb.push({ r: nr, c: nc })
      }
      return nb
    }
    function takeBest() {
      let idx = 0
      let best = fScore.get(key(open[0].r, open[0].c)) ?? Number.POSITIVE_INFINITY
      for (let i = 1; i < open.length; i++) {
        const fs = fScore.get(key(open[i].r, open[i].c)) ?? Number.POSITIVE_INFINITY
        if (fs < best) {
          best = fs
          idx = i
        }
      }
      const node = open[idx]
      open.splice(idx, 1)
      return node
    }

    while (open.length) {
      const current = takeBest()
      visitedRef.current.add(key(current.r, current.c))
      if (current.r === goal.r && current.c === goal.c) {
        let cur = key(current.r, current.c)
        pathRef.current.add(cur)
        while (came.has(cur)) {
          const prev = came.get(cur)!
          pathRef.current.add(prev)
          cur = prev
        }
        break
      }
      for (const nb of neighbors(current.r, current.c)) {
        const ck = key(current.r, current.c),
          nk = key(nb.r, nb.c)
        const tentative = (gScore.get(ck) ?? Number.POSITIVE_INFINITY) + 1
        if (tentative < (gScore.get(nk) ?? Number.POSITIVE_INFINITY)) {
          came.set(nk, ck)
          gScore.set(nk, tentative)
          const h = algo === "A*" && hasHeuristic ? heuristic(nb, goal) : 0
          fScore.set(nk, tentative + h)
          if (!open.find((o) => o.r === nb.r && o.c === nb.c)) open.push(nb)
        }
      }
      await delay(20)
    }
    setAnimating(false)
  }

  return (
    <div className="flex flex-col gap-8">
      <div className="rounded-xl border-2 border-blue-100 bg-gradient-to-r from-blue-50 to-emerald-50 p-6">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">🎯 Intelligent Algorithm Recommendation</h2>
        <p className="text-gray-600 mb-4 leading-relaxed">
          Configure problem parameters below. AlgoLens analyzes your requirements and recommends the optimal algorithm,
          then provides interactive visualization with performance insights.
        </p>
        <div className="flex items-center gap-4">
          <label className="text-sm font-semibold text-gray-700">Problem Type:</label>
          <select
            className="rounded-lg border-2 border-gray-200 px-4 py-2 text-sm font-medium bg-white shadow-sm hover:border-blue-300 focus:border-blue-500 focus:ring-2 focus:ring-blue-200 transition-colors"
            value={problemType}
            onChange={(e) => setProblemType(e.target.value as ProblemType)}
          >
            <option>Sorting</option>
            <option>Pathfinding</option>
          </select>
        </div>
      </div>

      {problemType === "Sorting" ? (
        <div className="rounded-xl border-2 border-emerald-100 bg-white p-6 shadow-lg">
          <h3 className="text-xl font-bold text-gray-900 mb-4">📊 Sorting Algorithm Configuration</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
            <div className="space-y-2">
              <label className="block text-sm font-semibold text-gray-700">Array Size</label>
              <input
                type="range"
                min={10}
                max={120}
                value={n}
                onChange={(e) => setN(Number.parseInt(e.target.value))}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
              />
              <div className="flex justify-between text-xs text-gray-500">
                <span>10</span>
                <span className="font-semibold text-blue-600">{n} elements</span>
                <span>120</span>
              </div>
            </div>

            <div className="space-y-3">
              <label className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors">
                <input
                  type="checkbox"
                  checked={duplicates}
                  onChange={(e) => setDuplicates(e.target.checked)}
                  className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                />
                <span className="text-sm font-medium text-gray-700">Contains duplicates</span>
              </label>

              <label className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg cursor-pointer hover:bg-gray-100 transition-colors">
                <input
                  type="checkbox"
                  checked={partiallySorted}
                  onChange={(e) => setPartiallySorted(e.target.checked)}
                  className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                />
                <span className="text-sm font-medium text-gray-700">Partially sorted</span>
              </label>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-4 mb-6">
            <button
              className="px-6 py-3 rounded-lg bg-gradient-to-r from-emerald-600 to-emerald-700 text-white font-semibold shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-200"
              onClick={() => setSortingAlgo(recommendedSorting)}
            >
              🎯 Get Recommendation
            </button>
            <button
              className="px-6 py-3 rounded-lg bg-gradient-to-r from-gray-800 to-gray-900 text-white font-semibold shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-200"
              onClick={() => askBackend("Sorting")}
            >
              🤖 Ask ML API
            </button>
            {sortingAlgo && (
              <div className="px-4 py-2 bg-blue-100 text-blue-800 rounded-lg font-semibold">
                Recommended: <span className="text-blue-900">{sortingAlgo}</span>
              </div>
            )}
            <button
              className="px-6 py-3 rounded-lg bg-gradient-to-r from-blue-600 to-blue-700 text-white font-semibold shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
              onClick={() => runSort(sortingAlgo ?? recommendedSorting)}
              disabled={isSorting}
            >
              {isSorting ? "🔄 Sorting..." : `▶️ Visualize ${sortingAlgo ?? recommendedSorting}`}
            </button>
            <button
              className="px-4 py-2 rounded-lg border-2 border-gray-300 text-gray-700 font-medium hover:border-gray-400 hover:bg-gray-50 transition-colors disabled:opacity-50"
              onClick={regenerateArray}
              disabled={isSorting}
            >
              🔄 Regenerate Array
            </button>
          </div>

          {apiRec && (
            <div className="mt-3 rounded-md border p-3 text-sm bg-gray-50">
              <div className="font-medium">API Suggests:</div>
              <div className="mt-1">Algorithms: {apiRec.algorithms.join(", ")}</div>
              <div className="mt-1 text-muted-foreground">Reason: {apiRec.rationale}</div>
            </div>
          )}

          <div className="mt-6 h-64 w-full rounded-xl border-2 border-gray-200 bg-gradient-to-b from-gray-50 to-white p-4 flex items-end gap-1 overflow-hidden shadow-inner">
            {arr.map((v, idx) => {
              const h = (v / (barMax || 1)) * 100
              return (
                <div
                  key={idx}
                  className={`flex-1 rounded-t-sm transition-all duration-200 ${
                    highlight === idx
                      ? "bg-gradient-to-t from-emerald-600 to-emerald-400 shadow-lg"
                      : "bg-gradient-to-t from-blue-600 to-blue-400"
                  }`}
                  style={{ height: `${h}%` }}
                  aria-label={`bar-${idx}`}
                />
              )
            })}
          </div>

          <p className="mt-2 text-xs text-muted-foreground">
            QuickSort avg O(n log n), worst O(n²); MergeSort stable O(n log n) with extra space; HeapSort O(n log n),
            in-place; InsertionSort O(n²) but strong on small/partially sorted inputs.
          </p>
        </div>
      ) : (
        <div className="rounded-xl border-2 border-purple-100 bg-white p-6 shadow-lg">
          <h3 className="text-xl font-bold text-gray-900 mb-4">🗺️ Pathfinding Algorithm Configuration</h3>
          <div className="mt-3 grid grid-cols-1 md:grid-cols-3 gap-4">
            <label className="flex items-center gap-2 text-sm">
              <span>Wall Density</span>
              <input
                type="range"
                min={0}
                max={0.6}
                step={0.05}
                value={density}
                onChange={(e) => setDensity(Number.parseFloat(e.target.value))}
              />
              <span className="text-muted-foreground">{Math.round(density * 100)}%</span>
            </label>
            <label className="flex items-center gap-2 text-sm">
              <input type="checkbox" checked={hasHeuristic} onChange={(e) => setHasHeuristic(e.target.checked)} />
              <span>Heuristic available</span>
            </label>
          </div>

          <div className="mt-4 flex flex-wrap items-center gap-3">
            <button
              className="px-6 py-3 rounded-lg bg-gradient-to-r from-emerald-600 to-emerald-700 text-white font-semibold shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-200"
              onClick={() => setPathAlgo(recommendedPath)}
            >
              🎯 Get Recommendation
            </button>
            <button
              className="px-6 py-3 rounded-lg bg-gradient-to-r from-gray-800 to-gray-900 text-white font-semibold shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-200"
              onClick={() => askBackend("Pathfinding")}
            >
              🤖 Ask ML API
            </button>
            {pathAlgo && (
              <div className="px-4 py-2 bg-blue-100 text-blue-800 rounded-lg font-semibold">
                Recommended: <span className="text-blue-900">{pathAlgo}</span>
              </div>
            )}
            <button
              className="px-6 py-3 rounded-lg bg-gradient-to-r from-blue-600 to-blue-700 text-white font-semibold shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
              onClick={() => runPathfinding(pathAlgo ?? recommendedPath)}
              disabled={animating}
            >
              {animating ? "🔄 Pathfinding..." : `▶️ Visualize ${pathAlgo ?? recommendedPath}`}
            </button>
            <button
              className="px-4 py-2 rounded-lg border-2 border-gray-300 text-gray-700 font-medium hover:border-gray-400 hover:bg-gray-50 transition-colors disabled:opacity-50"
              onClick={regenerateGrid}
              disabled={animating}
            >
              🔄 Regenerate Grid
            </button>
          </div>

          {apiRec && (
            <div className="mt-3 rounded-md border p-3 text-sm bg-gray-50">
              <div className="font-medium">API Suggests:</div>
              <div className="mt-1">Algorithms: {apiRec.algorithms.join(", ")}</div>
              <div className="mt-1 text-muted-foreground">Reason: {apiRec.rationale}</div>
            </div>
          )}

          <div className="mt-6 p-4 bg-gray-50 rounded-xl border-2 border-gray-200">
            <div className="grid gap-1" style={{ gridTemplateColumns: `repeat(${cols}, minmax(0,1fr))` }}>
              {grid.map((row, r) =>
                row.map((cell, c) => {
                  const k = `${r}:${c}`
                  const isStart = r === start.r && c === start.c
                  const isGoal = r === goal.r && c === goal.c
                  const visited = visitedRef.current.has(k)
                  const inPath = pathRef.current.has(k)
                  return (
                    <div
                      key={k}
                      className={`aspect-square border border-gray-300 transition-all duration-200 ${
                        isStart
                          ? "bg-green-500 shadow-lg"
                          : isGoal
                            ? "bg-red-500 shadow-lg"
                            : cell === 1
                              ? "bg-gray-800"
                              : inPath
                                ? "bg-emerald-500 shadow-md"
                                : visited
                                  ? "bg-blue-400"
                                  : "bg-white"
                      }`}
                      aria-label={`cell-${k}${isStart ? "-start" : ""}${isGoal ? "-goal" : ""}`}
                      title={isStart ? "🚀 Start" : isGoal ? "🎯 Goal" : ""}
                    />
                  )
                }),
              )}
            </div>
          </div>

          <p className="mt-2 text-xs text-muted-foreground">
            Dijkstra explores uniformly with non-negative edges; A* uses an admissible heuristic (Manhattan here) to
            guide the search and typically expands fewer nodes.
          </p>
        </div>
      )}
    </div>
  )
}
