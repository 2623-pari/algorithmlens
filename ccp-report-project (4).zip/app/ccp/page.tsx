"use client"

import { useState } from "react"
import AlgoLens from "@/components/algo-lens"
import ReportBuilder from "@/components/report-builder"

export default function CCPPage() {
  const [tab, setTab] = useState<"preview" | "report">("preview")

  return (
    <main className="min-h-screen bg-white text-gray-900">
      <header className="border-b">
        <div className="mx-auto max-w-5xl px-4 py-4 flex items-center justify-between">
          <h1 className="text-balance text-xl md:text-2xl font-semibold text-gray-900">
            AlgoLens — Core Course Project (CCP)
          </h1>
          <nav className="flex items-center gap-2">
            <button
              onClick={() => setTab("preview")}
              className={`px-3 py-2 rounded-md text-sm font-medium ${tab === "preview" ? "bg-blue-600 text-white" : "bg-gray-100 text-gray-900"}`}
            >
              Project Preview
            </button>
            <button
              onClick={() => setTab("report")}
              className={`px-3 py-2 rounded-md text-sm font-medium ${tab === "report" ? "bg-blue-600 text-white" : "bg-gray-900 text-white md:text-gray-900 md:bg-gray-100"}`}
            >
              Report Builder
            </button>
          </nav>
        </div>
      </header>

      <section className="mx-auto max-w-5xl px-4 py-6">{tab === "preview" ? <AlgoLens /> : <ReportBuilder />}</section>
    </main>
  )
}
