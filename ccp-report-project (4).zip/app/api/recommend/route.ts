import type { NextRequest } from "next/server"

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const problemType: string = String(body?.problemType || "").toLowerCase()

    let recommendation = {
      algorithms: [] as string[],
      rationale: "",
    }

    if (["sort", "sorting", "order"].some((k) => problemType.includes(k))) {
      recommendation = {
        algorithms: ["Insertion Sort (small n/partially sorted)", "Merge Sort", "Quick Sort", "Heap Sort"],
        rationale:
          "Insertion Sort is strong for small or partially sorted arrays; Merge Sort is stable O(n log n); Quick Sort is fast on average; Heap Sort gives predictable O(n log n).",
      }
    } else if (["path", "route", "graph", "shortest"].some((k) => problemType.includes(k))) {
      recommendation = {
        algorithms: ["Dijkstra (non-negative weights)", "A* (admissible heuristic)", "BFS (unweighted graphs)"],
        rationale:
          "Use Dijkstra when weights are non-negative; A* reduces expansions with an admissible heuristic; BFS is optimal for unweighted graphs.",
      }
    } else {
      recommendation = {
        algorithms: ["Clarify constraints"],
        rationale:
          "Specify input size, structure (array/graph), weights, and optimality requirements to refine the recommendation.",
      }
    }

    return new Response(JSON.stringify({ ok: true, recommendation }), {
      status: 200,
      headers: { "content-type": "application/json" },
    })
  } catch {
    return new Response(JSON.stringify({ ok: false, error: "Invalid JSON" }), {
      status: 400,
      headers: { "content-type": "application/json" },
    })
  }
}
