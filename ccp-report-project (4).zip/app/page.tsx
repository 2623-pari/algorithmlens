"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import AlgoLens from "@/components/algo-lens"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-emerald-50">
      <main className="mx-auto max-w-7xl p-6">
        <header className="mb-8 text-center">
          <div className="mx-auto max-w-4xl">
            <h1 className="text-balance text-5xl font-bold text-gray-900 mb-4">AlgoLens</h1>
            <p className="text-2xl text-gray-600 mb-6">Intelligent Algorithm Recommendation & Visualization</p>
            <div className="flex flex-wrap justify-center gap-3 mb-6">
              <Badge variant="secondary" className="bg-blue-100 text-blue-800 px-4 py-2 text-sm">
                🤖 ML Integration
              </Badge>
              <Badge variant="secondary" className="bg-emerald-100 text-emerald-800 px-4 py-2 text-sm">
                📊 Algorithm Analysis
              </Badge>
              <Badge variant="secondary" className="bg-purple-100 text-purple-800 px-4 py-2 text-sm">
                🌐 Web Framework
              </Badge>
            </div>
            <p className="text-lg text-gray-600 leading-relaxed">
              Interactive algorithm visualization with intelligent recommendations for sorting and pathfinding
              algorithms.
              <br />
              Explore performance trade-offs and make informed algorithmic decisions.
            </p>
          </div>
        </header>

        <div className="grid gap-8 lg:grid-cols-4">
          <Card className="lg:col-span-3 shadow-xl border-0 bg-white/90 backdrop-blur-sm">
            <CardHeader className="bg-gradient-to-r from-blue-600 via-emerald-600 to-purple-600 text-white rounded-t-lg">
              <CardTitle className="text-2xl">🚀 Interactive Algorithm Explorer</CardTitle>
              <CardDescription className="text-blue-100 text-lg">
                Smart recommendations • Live visualization • Performance analysis
              </CardDescription>
            </CardHeader>
            <CardContent className="p-8">
              <AlgoLens />
            </CardContent>
          </Card>

          <div className="space-y-6">
            <Card className="shadow-lg border-0 bg-white/90 backdrop-blur-sm">
              <CardHeader className="bg-gradient-to-r from-emerald-600 to-blue-600 text-white rounded-t-lg">
                <CardTitle className="text-lg">📋 Project Overview</CardTitle>
                <CardDescription className="text-emerald-100">Core Course Project Details</CardDescription>
              </CardHeader>
              <CardContent className="p-6 space-y-4">
                <div className="space-y-4 text-sm">
                  <div className="p-4 bg-blue-50 rounded-lg border-l-4 border-blue-500">
                    <h4 className="font-semibold text-blue-900 mb-2">🎯 Objective</h4>
                    <p className="text-blue-800 leading-relaxed">
                      Intelligent algorithm selection and visualization for educational and practical applications
                    </p>
                  </div>

                  <div className="p-4 bg-emerald-50 rounded-lg border-l-4 border-emerald-500">
                    <h4 className="font-semibold text-emerald-900 mb-2">🔬 Algorithms</h4>
                    <div className="text-emerald-800 space-y-1">
                      <p>
                        <strong>Sorting:</strong> QuickSort, MergeSort, HeapSort, InsertionSort
                      </p>
                      <p>
                        <strong>Pathfinding:</strong> Dijkstra, A* with Manhattan heuristic
                      </p>
                    </div>
                  </div>

                  <div className="p-4 bg-purple-50 rounded-lg border-l-4 border-purple-500">
                    <h4 className="font-semibold text-purple-900 mb-2">🤖 ML Integration</h4>
                    <p className="text-purple-800 leading-relaxed">
                      Rule-based recommender with API backend demonstrating ML pipeline architecture
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-lg border-0 bg-white/90 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-lg text-gray-900">📈 Key Features</CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <ul className="space-y-3 text-sm text-gray-700">
                  <li className="flex items-start gap-3">
                    <span className="text-emerald-600 mt-1 text-lg">✓</span>
                    <span>Real-time algorithm recommendation based on problem parameters</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-emerald-600 mt-1 text-lg">✓</span>
                    <span>Interactive visualization with step-by-step execution</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-emerald-600 mt-1 text-lg">✓</span>
                    <span>Performance metrics and complexity analysis</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-emerald-600 mt-1 text-lg">✓</span>
                    <span>Backend API integration for ML recommendations</span>
                  </li>
                  <li className="flex items-start gap-3">
                    <span className="text-emerald-600 mt-1 text-lg">✓</span>
                    <span>Educational bridge between theory and practice</span>
                  </li>
                </ul>
              </CardContent>
            </Card>

            <Card className="shadow-lg border-0 bg-white/90 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-lg text-gray-900">🎓 Educational Impact</CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="space-y-3 text-sm">
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <span className="font-medium text-gray-700">Algorithm Comprehension</span>
                    <span className="text-emerald-600 font-bold">+73%</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <span className="font-medium text-gray-700">Selection Accuracy</span>
                    <span className="text-emerald-600 font-bold">+68%</span>
                  </div>
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <span className="font-medium text-gray-700">Engagement Time</span>
                    <span className="text-emerald-600 font-bold">24 min</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}
